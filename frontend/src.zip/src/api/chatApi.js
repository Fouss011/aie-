const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

export async function askAssistant(question, structureId, history = []) {
  const response = await fetch(`${API_URL}/api/chat`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      question,
      structureId,
      history,
    }),
  });

  let data = null;

  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (response.status === 403) {
    throw new Error("SUBSCRIPTION_REQUIRED");
  }

  if (!response.ok) {
    throw new Error(data?.error || "Impossible de contacter l’assistant.");
  }

  return data;
}